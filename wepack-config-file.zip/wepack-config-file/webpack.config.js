module.exports = {
	// define entry point
	
	entry: "./js/script1.js",
	
	//define output point
	output: {
		path:'dist',
		filename:'bundle.js'
	}
};