var message = require('./script2.js')
alert(message);