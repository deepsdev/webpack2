var message = require('./script2.js');
require('../css/style1.css');